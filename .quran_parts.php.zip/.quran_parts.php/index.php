<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تقسيم الأجزاء</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>تقسيم الأجزاء</h1>
    <div class="form-container">
        <form method="GET">
            <input type="text" name="name" placeholder="أدخل اسمك" required>
            <select name="part" required>
                <?php
                for ($i = 1; $i <= 30; $i++) {
                    echo "<option value='$i'>الجزء $i</option>";
                }
                ?>
            </select>
            <button type="submit">حفظ</button>
        </form>
    </div>

    <div class="container">
        <?php
        ini_set('display_errors', 1);
        error_reporting(E_ALL);

        $quran_parts = [];
        for ($i = 1; $i <= 30; $i++) {
            $quran_parts[$i] = "الجزء $i";
        }

        $booked_parts = [];
        if (file_exists('booked_parts.json')) {
            $booked_parts = json_decode(file_get_contents('booked_parts.json'), true);
        }

        if (isset($_GET['name'], $_GET['part'])) {
            $name = htmlspecialchars($_GET['name']);
            $part = (int)$_GET['part'];
            if (!isset($booked_parts[$part])) {
                $booked_parts[$part] = $name;
                file_put_contents('booked_parts.json', json_encode($booked_parts));
            }
        }

        foreach ($quran_parts as $part => $name) {
            $isReserved = isset($booked_parts[$part]);
            echo "<div class='card'>";
            echo "<h2>$name</h2>";
            if ($isReserved) {
                echo "<p class='reserved'>محجوز بواسطة: " . htmlspecialchars($booked_parts[$part]) . "</p>";
            } else {
                echo "<p class='unreserved'>غير مخصص</p>";
            }
            echo "</div>";
        }
        ?>
    </div>
</body>
</html>